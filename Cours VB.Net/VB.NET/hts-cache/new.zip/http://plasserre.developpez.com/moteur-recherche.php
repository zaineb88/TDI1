<html><head>
<META NAME="DESCRIPTION" CONTENT="Le portail du d�veloppement PHP des jeunes Webmasters">
<META NAME="KEYWORDS" CONTENT="script, php, code, html, balises, programmation, javascript, web, webmaster, ressources, webmestre, jeune, d�buter, commencer, langage">
<META NAME="REPLY-TO" CONTENT="eroan@free.fr">
<META NAME="AUTHOR" CONTENT="Eroan Boyer">
<META HTTP-EQUIV="imagetoolbar" CONTENT="no">
<META HTTP-EQUIV="CONTENT-LANGUAGE" CONTENT="fr">
<META HTTP-EQUIV="VW96.OBJECT TYPE" CONTENT="Archive">
<META NAME="ROBOTS" CONTENT="index,follow">
<META NAME="REVISIT-AFTER" CONTENT="15 days">
<META NAME="ROBOTS" CONTENT="ALL">




<body background="vfond.jpg" leftmargin="90">

<p>&nbsp;</p>
<table border="0" cellpadding="0" cellspacing="0" style="border-collapse: collapse" bordercolor="#111111" width="100%" id="AutoNumber1" height="62">
  <tr>
    <td width="18%" height="62">
    <img border="0" src="vhom.gif" width="102" height="62"><img border="0" src="vvb.gif" width="31" height="24"></td>
    <td width="73%" height="62">
    <p align="center"><b><font color="#0000FF" face="Courier New" size="7">Cours 
    VB.net</font></b></td>
  </tr>
</table>
<font face="Courier New" size="2"> </font></b></p>
<font face="Courier New" size="2">Tapez un mot, mettre un espace avant et apr�s si n�cessaire</font></b></p>
<font face="Courier New" size="2"> </font></b></p>






<TITLE>Jeunes Webmasters :: Moteur de recherche du site ::</TITLE>
</head><body>

<table border="0" width="100%" cellspacing="0" cellpadding="2" bgcolor="#CC99FF"><tr>
<td width="100%" bgcolor="#EFDFFF">

<center><form method="POST" name="form" action="moteur-recherche.php">
Rechercher : <input type="text" name="search" value="Mots cl�s" onFocus="if (this.value=='Mots cl�s') {this.value=''}">
<input type="submit" value="Valider" name="submit" onClick="this.value='Patientez...';">
</center></td></tr></table><br>


<br><br><center>Script d�velopp� par <a href="http://www.jeunes-webmasters.com" target="_blank">Jeunes Webmasters</a> (Tous les Scripts PHP gratuits)<br>J-Web Easy Search v1.1 tous droits r�serv�s</center>
</body></html>